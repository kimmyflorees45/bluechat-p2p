# BlueChat P2P

Una aplicación de chat P2P por Bluetooth desarrollada en Flutter.

## Características

- 🔵 Chat Bluetooth P2P en tiempo real
- 💾 Persistencia de mensajes con SQLite
- 📱 Interfaz moderna con Material Design
- 🔒 Gestión automática de permisos
- 📋 Múltiples conversaciones

## Instalación

1. Descarga el APK desde las releases
2. Habilita "Fuentes desconocidas" en tu Android
3. Instala el APK
4. Concede los permisos de Bluetooth

## Build

Este proyecto se compila automáticamente con GitHub Actions.
El APK se genera en cada push a la rama main.

## Permisos requeridos

- Bluetooth
- Ubicación (para descubrimiento Bluetooth)
- Almacenamiento (para base de datos)

¡Disfruta tu chat Bluetooth P2P!
