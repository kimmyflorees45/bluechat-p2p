import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'screens/home_screen.dart';
import 'services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize notification service
  await NotificationService().initialize();
  
  // Request permissions
  await _requestPermissions();
  
  runApp(const BlueChatAppFixed());
}

Future<void> _requestPermissions() async {
  await [
    Permission.bluetooth,
    Permission.bluetoothScan,
    Permission.bluetoothConnect,
    Permission.bluetoothAdvertise,
    Permission.location,
    Permission.storage,
    Permission.camera,
    Permission.notification,
  ].request();
}

class BlueChatAppFixed extends StatelessWidget {
  const BlueChatAppFixed({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Blue Chat P2P Fixed',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
